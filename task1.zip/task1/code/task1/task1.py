from docx import Document
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer
from reportlab.lib.styles import getSampleStyleSheet
# import os

def docx_to_pdf(docx_file, pdf_file):
    try:
        # Load .docx file
        document = Document(docx_file)
        
        # Create a PDF document
        pdf = SimpleDocTemplate(pdf_file)
        styles = getSampleStyleSheet()
        content = []

        # Extract text from the .docx file and add it to the PDF
        for para in document.paragraphs:
            text = para.text.strip()
            if text:
                content.append(Paragraph(text, styles['Normal']))
                content.append(Spacer(1, 12))

        # Build and save the PDF
        pdf.build(content)
        print(f"Successfully converted {docx_file} to {pdf_file}")

    except Exception as e:
        print(f"Error: {e}")

# Example usage
if __name__ == "__main__":
    input_docx = "D://tasks//task1//sample.docx"  # Replace with your .docx file path
    output_pdf = "D://tasks//task1//output.pdf"   # Replace with desired .pdf file path

    docx_to_pdf(input_docx, output_pdf)

